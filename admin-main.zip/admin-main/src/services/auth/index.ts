import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';

import { RootState } from '@/store';
import { BASE_API_URL } from '@/config';

type LoginRequest = {
	username: string;
	password: string;
};

type LoginResponse = {
	status: string;
	data: {
		access_token: string;
		id: string;
		username: string;
		fullName: string;
	};
};

export const authApi = createApi({
	reducerPath: 'authApi',
	baseQuery: fetchBaseQuery({
		baseUrl: `${BASE_API_URL}/auth`,
		prepareHeaders: (headers, { getState }) => {
			const token = (getState() as RootState).user.accessToken;

			if (token) headers.set('authorization', `Bearer ${token}`);

			return headers;
		}
	}),
	endpoints: (builder) => ({
		login: builder.mutation<LoginResponse, LoginRequest>({
			query: (credentials) => ({
				url: 'login',
				method: 'POST',
				body: credentials
			})
		})
	})
});

export const { useLoginMutation } = authApi;
