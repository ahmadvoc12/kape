import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';

import { RootState } from '@/store';
import { BASE_API_URL } from '@/config';

enum Role {
	Admin = 'admin',
	Employee = 'employee'
}

type UserListResponse = {
	status: string;
	data: {
		id: string;
		username: string;
		fullName: string;
		role: Role;
		createdAt: Date;
		updatedAt: Date;
	}[];
};

export const usersApi = createApi({
	reducerPath: 'usersApi',
	baseQuery: fetchBaseQuery({
		baseUrl: `${BASE_API_URL}/users`,
		prepareHeaders: (headers, { getState }) => {
			const token = (getState() as RootState).user.accessToken;

			if (token) headers.set('authorization', `Bearer ${token}`);

			return headers;
		}
	}),
	endpoints: (builder) => ({
		getUserList: builder.query({
			query: () => '/',
			transformResponse: (response: UserListResponse) => {
				return response.data.map((u) => {
					return {
						id: u.id,
						username: u.username,
						fullName: u.fullName,
						role: u.role
					};
				});
			}
		})
	})
});

export const { useGetUserListQuery } = usersApi;
