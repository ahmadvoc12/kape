const BASE_API_PROTOCOL = import.meta.env.VITE_BASE_API_PROTOCOL;
const BASE_API_HOST = import.meta.env.VITE_BASE_API_HOST;
const BASE_API_PORT = import.meta.env.VITE_BASE_API_PORT;
const BASE_API_PATH = import.meta.env.VITE_BASE_API_PATH;
const BASE_API_URL = `${BASE_API_PROTOCOL}://${BASE_API_HOST}:${BASE_API_PORT}${BASE_API_PATH}`;

export { BASE_API_URL };
