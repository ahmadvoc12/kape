import React from 'react';
import { useRoutes } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { ThemeProvider, StyledEngineProvider } from '@material-ui/core';
import CssBaseline from '@material-ui/core/CssBaseline';

import GlobalStyles from '@/GlobalStyles';
import theme from '@/theme';
import routes from './router';
import Snackbar from '@/components/snackbar';

const App = () => {
	const routing = useRoutes(routes);

	return (
		<>
			<StyledEngineProvider injectFirst>
				<ThemeProvider theme={theme}>
					<CssBaseline />
					<GlobalStyles />
					<Helmet
						titleTemplate="%s | NekoToko Admin"
						defaultTitle="NekoToko Admin"
					/>
					<Snackbar />
					{routing}
				</ThemeProvider>
			</StyledEngineProvider>
		</>
	);
};

export default App;
