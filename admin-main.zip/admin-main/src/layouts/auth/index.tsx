import React, { Suspense } from 'react';
import { Outlet } from 'react-router-dom';
import { experimentalStyled } from '@material-ui/core';
import AuthNavbar from '@/components/layouts/auth/AuthNavbar';

const AuthLayoutRoot = experimentalStyled('div')(({ theme }) => ({
	backgroundColor: theme.palette.background.paper,
	display: 'flex',
	height: '100%',
	overflow: 'hidden',
	width: '100%'
}));

const AuthLayoutWrapper = experimentalStyled('div')({
	display: 'flex',
	flex: '1 1 auto',
	overflow: 'hidden',
	paddingTop: 64
});

const AuthLayoutContainer = experimentalStyled('div')({
	display: 'flex',
	flex: '1 1 auto',
	overflow: 'hidden'
});

const AuthLayoutContent = experimentalStyled('div')({
	flex: '1 1 auto',
	height: '100%',
	overflow: 'auto'
});

const AuthLayout = () => (
	<AuthLayoutRoot>
		<AuthNavbar />
		<AuthLayoutWrapper>
			<AuthLayoutContainer>
				<AuthLayoutContent>
					<Suspense fallback={<div>Loading...</div>}>
						<Outlet />
					</Suspense>
				</AuthLayoutContent>
			</AuthLayoutContainer>
		</AuthLayoutWrapper>
	</AuthLayoutRoot>
);

export default AuthLayout;
