import React, { useState, Suspense } from 'react';
import { Outlet } from 'react-router-dom';
import { experimentalStyled, Box } from '@material-ui/core';

import MainNavbar from '@/components/layouts/main/MainNavbar';
import MainDrawer from '@/components/layouts/main/MainDrawer';

const MainLayoutRoot = experimentalStyled('div')(({ theme }) => ({
	backgroundColor: theme.palette.background.default,
	display: 'flex',
	height: '100%',
	overflow: 'hidden',
	width: '100%'
}));

const MainLayoutWrapper = experimentalStyled('div')(({ theme }) => ({
	display: 'flex',
	flex: '1 1 auto',
	overflow: 'hidden',
	paddingTop: 64,
	[theme.breakpoints.up('lg')]: {
		paddingLeft: 256
	}
}));

const MainLayoutContainer = experimentalStyled('div')({
	display: 'flex',
	flex: '1 1 auto',
	overflow: 'hidden'
});

const MainLayoutContent = experimentalStyled('div')({
	flex: '1 1 auto',
	height: '100%',
	overflow: 'auto'
});

const MainLayout: React.FC = () => {
	const [isMobileNavOpen, setMobileNavOpen] = useState(false);

	return (
		<MainLayoutRoot>
			<MainNavbar onMobileNavOpen={() => setMobileNavOpen(true)} />
			<MainDrawer
				onMobileClose={() => setMobileNavOpen(false)}
				openMobile={isMobileNavOpen}
			/>
			<MainLayoutWrapper>
				<MainLayoutContainer>
					<MainLayoutContent>
						<Box component="div" sx={{ p: 3 }}>
							<Suspense fallback={<div>Loading...</div>}>
								<Outlet />
							</Suspense>
						</Box>
					</MainLayoutContent>
				</MainLayoutContainer>
			</MainLayoutWrapper>
		</MainLayoutRoot>
	);
};

export default MainLayout;
