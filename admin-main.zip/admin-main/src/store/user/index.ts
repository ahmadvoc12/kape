import { createSlice, PayloadAction } from '@reduxjs/toolkit';

export type UserState = {
	readonly username: string;
	readonly fullName: string;
	readonly accessToken: string;
	readonly avatar: string;
};

const initialState: UserState = {
	username: '',
	fullName: '',
	accessToken: '',
	avatar: ''
};

export const userSlice = createSlice({
	name: 'user',
	initialState: localStorage.getItem('user')
		? JSON.parse(localStorage.getItem('user') as string)
		: initialState,
	reducers: {
		setUser: (
			state,
			action: PayloadAction<{ username: string; fullName: string }>
		) => {
			state.username = action.payload.username;
			state.fullName = action.payload.fullName;
		},
		setAccessToken: (state, action: PayloadAction<string>) => {
			state.accessToken = action.payload;
		}
	}
});

export const { setUser, setAccessToken } = userSlice.actions;

export const selectUser = (state: UserState) => state;
export const selectAccessToken = (state: UserState) => state.accessToken;

export default userSlice.reducer;
