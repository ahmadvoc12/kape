import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { AlertColor } from '@material-ui/core';

export type SnackbarState = {
	readonly open: boolean;
	readonly severity: AlertColor;
	readonly message: string;
};

const initialState: SnackbarState = {
	open: false,
	severity: 'success',
	message: ''
};

export const snackbarSlice = createSlice({
	name: 'settings',
	initialState,
	reducers: {
		setSnackbar: (
			state,
			action: PayloadAction<{
				open: boolean;
				severity: AlertColor;
				message: string;
			}>
		) => {
			state.open = action.payload.open;
			state.severity = action.payload.severity;
			state.message = action.payload.message;
		}
	}
});

export const { setSnackbar } = snackbarSlice.actions;

export const selectSnackbar = (state: SnackbarState) => state;

export default snackbarSlice.reducer;
