import { configureStore } from '@reduxjs/toolkit';

import snackbarReducer from './snackbar';
import userReducer from './user';
import { authApi } from '@/services/auth';
import { usersApi } from '@/services/users';

export const store = configureStore({
	reducer: {
		snackbar: snackbarReducer,
		[authApi.reducerPath]: authApi.reducer,
		[usersApi.reducerPath]: usersApi.reducer,
		user: userReducer
	},
	middleware: (getDefaultMiddleware) =>
		getDefaultMiddleware().concat(authApi.middleware, usersApi.middleware)
});

export type AppDispatch = typeof store.dispatch;
export type RootState = ReturnType<typeof store.getState>;

store.subscribe(() => {
	localStorage.setItem('user', JSON.stringify(store.getState().user));
});
