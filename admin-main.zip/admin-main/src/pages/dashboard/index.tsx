import React from 'react';
import { Helmet } from 'react-helmet';

const DashboardPage = () => {
	return (
		<>
			<Helmet>
				<title>Dashboard</title>
			</Helmet>
			Dashboard
		</>
	);
};

export default DashboardPage;
