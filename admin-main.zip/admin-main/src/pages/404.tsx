import React from 'react';

const NotFoundPage = () => {
	return <div>404 Not Found</div>;
};

export default NotFoundPage;
