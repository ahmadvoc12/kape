import React from 'react';
import { Helmet } from 'react-helmet';
import { Typography, Box } from '@material-ui/core';

import UsersTable from '@/components/users/UsersTable';
import { useGetUserListQuery } from '@/services/users';

const UsersPage = () => {
	const { data, isLoading } = useGetUserListQuery('');

	return (
		<>
			<Helmet>
				<title>Users</title>
			</Helmet>

			<Typography variant="h1">Users</Typography>

			<Box sx={{ mt: 4 }}>
				{isLoading && !data ? (
					<div>Loading...</div>
				) : (
					<UsersTable userList={data} />
				)}
			</Box>
		</>
	);
};

export default UsersPage;
