import React from 'react';
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import * as Yup from 'yup';
import { Formik } from 'formik';
import {
	Box,
	Button,
	Container,
	TextField,
	Typography
} from '@material-ui/core';

import { useLoginMutation } from '@/services/auth';
import { setUser, setAccessToken } from '@/store/user';
import { setSnackbar } from '@/store/snackbar';

const LoginPage = () => {
	const navigate = useNavigate();
	const dispatch = useDispatch();
	const [login, { isLoading }] = useLoginMutation();

	return (
		<>
			<Helmet>
				<title>Login</title>
			</Helmet>

			<Box
				sx={{
					backgroundColor: 'background.default',
					display: 'flex',
					flexDirection: 'column',
					height: '100%',
					justifyContent: 'center'
				}}
			>
				<Container maxWidth="sm">
					<Formik
						initialValues={{
							username: 'nekotoko',
							password: ''
						}}
						validationSchema={Yup.object().shape({
							username: Yup.string().max(255).required('Username is required'),
							password: Yup.string().max(255).required('Password is required')
						})}
						onSubmit={async (values) => {
							try {
								const res = await login({
									username: values.username,
									password: values.password
								}).unwrap();

								dispatch(setAccessToken(res.data.access_token));
								dispatch(
									setUser({
										username: res.data.username,
										fullName: res.data.fullName
									})
								);
								dispatch(
									setSnackbar({
										open: true,
										severity: 'success',
										message: 'Login succesfully'
									})
								);

								navigate('/');
							} catch (err) {
								dispatch(
									setSnackbar({
										open: true,
										severity: 'error',
										message: err.data.message
									})
								);
							}
						}}
					>
						{({
							errors,
							handleBlur,
							handleChange,
							handleSubmit,
							isSubmitting,
							touched,
							values
						}) => (
							<form onSubmit={handleSubmit}>
								<Box sx={{ mb: 3 }}>
									<Typography color="textPrimary" variant="h2">
										Sign in
									</Typography>
								</Box>
								<TextField
									error={Boolean(touched.username && errors.username)}
									fullWidth
									helperText={touched.username && errors.username}
									label="username Address"
									margin="normal"
									name="username"
									onBlur={handleBlur}
									onChange={handleChange}
									type="username"
									value={values.username}
									variant="outlined"
								/>
								<TextField
									error={Boolean(touched.password && errors.password)}
									fullWidth
									helperText={touched.password && errors.password}
									label="Password"
									margin="normal"
									name="password"
									onBlur={handleBlur}
									onChange={handleChange}
									type="password"
									value={values.password}
									variant="outlined"
								/>
								<Box sx={{ py: 2 }}>
									<Button
										color="primary"
										disabled={isSubmitting}
										fullWidth
										size="large"
										type="submit"
										variant="contained"
									>
										Sign in now
									</Button>
								</Box>
							</form>
						)}
					</Formik>
				</Container>
			</Box>
		</>
	);
};

export default LoginPage;
