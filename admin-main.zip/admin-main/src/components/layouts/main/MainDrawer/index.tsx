import React, { useEffect } from 'react';
import { Link as RouterLink, useLocation } from 'react-router-dom';
import {
	Avatar,
	Box,
	Divider,
	Drawer,
	Hidden,
	List,
	Typography
} from '@material-ui/core';

import { useAppSelector } from '@/hooks/store';
import NavItem from './NavItem';
import menuData from './menuData';

const MainSideNav = ({
	onMobileClose,
	openMobile
}: {
	onMobileClose: () => void;
	openMobile: boolean;
}) => {
	const location = useLocation();
	const user = useAppSelector((state) => state.user);

	useEffect(() => {
		if (openMobile && onMobileClose) {
			onMobileClose();
		}
	}, [location.pathname]);

	const content = (
		<Box
			sx={{
				display: 'flex',
				flexDirection: 'column',
				height: '100%'
			}}
		>
			<Box
				sx={{
					alignItems: 'center',
					display: 'flex',
					flexDirection: 'column',
					p: 2
				}}
			>
				<Avatar
					component={RouterLink}
					src={user.avatar}
					sx={{
						cursor: 'pointer',
						width: 64,
						height: 64,
						mb: 1
					}}
					to="/account"
				/>
				<Typography color="textPrimary" variant="h5">
					{user.username}
				</Typography>
				<Typography color="textSecondary" variant="body2">
					{user.fullName}
				</Typography>
			</Box>
			<Divider />
			<Box sx={{ p: 2 }}>
				<List>
					{menuData.map(({ title, key, icon, url }) => (
						<NavItem href={url} key={key} title={title} icon={icon} />
					))}
				</List>
			</Box>
		</Box>
	);

	return (
		<>
			<Hidden lgUp>
				<Drawer
					anchor="left"
					onClose={onMobileClose}
					open={openMobile}
					variant="temporary"
					PaperProps={{
						sx: {
							width: 256
						}
					}}
				>
					{content}
				</Drawer>
			</Hidden>
			<Hidden lgDown>
				<Drawer
					anchor="left"
					open
					variant="persistent"
					PaperProps={{
						sx: {
							width: 256,
							top: 64,
							height: 'calc(100% - 64px)'
						}
					}}
				>
					{content}
				</Drawer>
			</Hidden>
		</>
	);
};

export default MainSideNav;
