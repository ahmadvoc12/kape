import React from 'react';
import { Home, Person } from '@material-ui/icons';

const menuData = [
	{
		title: 'Dashboard',
		key: 'dashboard',
		icon: <Home />,
		url: '/dashboard'
	},
	{
		title: 'Users',
		key: 'users',
		icon: <Person />,
		url: '/users'
	}
];

export default menuData;
