import React, { useState } from 'react';
import { Link as RouterLink } from 'react-router-dom';
import {
	AppBar,
	Toolbar,
	Box,
	IconButton,
	Hidden,
	Badge
} from '@material-ui/core';
import {
	Menu as MenuIcon,
	NotificationsOutlined as NotificationsIcon,
	Input as InputIcon
} from '@material-ui/icons';

import Logo from '@/components/logo';

const MainNavbar = ({
	onMobileNavOpen,
	...rest
}: {
	onMobileNavOpen: () => void;
}) => {
	const [notifications] = useState([]);

	return (
		<>
			<AppBar position="fixed" {...rest}>
				<Toolbar>
					<RouterLink to="/">
						<Logo />
					</RouterLink>
					<Box sx={{ flexGrow: 1 }} />
					<Hidden lgDown>
						<IconButton color="inherit">
							<Badge
								badgeContent={notifications.length}
								color="primary"
								variant="dot"
							>
								<NotificationsIcon />
							</Badge>
						</IconButton>
						<IconButton color="inherit">
							<InputIcon />
						</IconButton>
					</Hidden>
					<Hidden lgUp>
						<IconButton color="inherit" onClick={onMobileNavOpen}>
							<MenuIcon />
						</IconButton>
					</Hidden>
				</Toolbar>
			</AppBar>
		</>
	);
};

export default MainNavbar;
