import React from 'react';
import { Link as RouterLink } from 'react-router-dom';
import { AppBar, Toolbar } from '@material-ui/core';

import Logo from '@/components/logo';

const AuthNavbar = ({ ...rest }) => {
	return (
		<>
			<AppBar position="fixed" {...rest}>
				<Toolbar>
					<RouterLink to="/">
						<Logo />
					</RouterLink>
				</Toolbar>
			</AppBar>
		</>
	);
};

export default AuthNavbar;
