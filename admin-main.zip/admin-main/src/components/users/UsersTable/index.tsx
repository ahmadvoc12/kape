import React from 'react';
import { Link } from 'react-router-dom';
import { Button, Stack, Box } from '@material-ui/core';
import {
	DataGrid,
	GridColDef,
	GridRowsProp,
	GridValueGetterParams
} from '@material-ui/data-grid';
import { Delete as DeleteIcon, Edit as EditIcon } from '@material-ui/icons';

const columns: GridColDef[] = [
	{
		field: 'username',
		headerName: 'Username',
		width: 220
	},
	{
		field: 'fullName',
		headerName: 'Full Name',
		width: 300
	},
	{
		field: 'role',
		headerName: 'Role',
		width: 120
	},
	{
		field: 'action',
		headerName: 'Action',
		width: 300,
		renderCell: (params: GridValueGetterParams) => (
			<Stack spacing={2} direction="row">
				<Link to={params.getValue(params.id, 'id') as string}>
					<Button variant="outlined" startIcon={<EditIcon />}>
						Edit
					</Button>
				</Link>
				<Box>
					<Button variant="outlined" color="error" startIcon={<DeleteIcon />}>
						Delete
					</Button>
				</Box>
			</Stack>
		)
	}
];

const UsersTable = ({ userList }: { userList: GridRowsProp }) => {
	return (
		<div style={{ height: '400px', width: '100%' }}>
			<DataGrid
				columns={columns}
				rows={userList}
				autoHeight
				rowsPerPageOptions={[10, 25, 50, 100]}
			/>
		</div>
	);
};

export default UsersTable;
