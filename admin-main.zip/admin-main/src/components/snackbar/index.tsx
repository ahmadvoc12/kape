import React from 'react';
import { useDispatch } from 'react-redux';
import {
	Snackbar as MaterialSnackbar,
	Alert,
	AlertTitle
} from '@material-ui/core';

import { useAppSelector } from '@/hooks/store';
import { setSnackbar } from '@/store/snackbar';
import { toProperCase } from '@/utils/string';

const Snackbar = () => {
	const dispatch = useDispatch();
	const snackbar = useAppSelector((state) => state.snackbar);

	const handleClose = (
		_: React.SyntheticEvent | React.MouseEvent,
		reason?: string
	) => {
		if (reason === 'clickaway') return;

		dispatch(
			setSnackbar({
				open: false,
				severity: snackbar.severity,
				message: snackbar.message
			})
		);
	};

	return (
		<MaterialSnackbar
			anchorOrigin={{
				vertical: 'top',
				horizontal: 'right'
			}}
			open={snackbar.open}
			autoHideDuration={5000}
			onClose={handleClose}
			ContentProps={{
				'aria-describedby': 'message-id'
			}}
		>
			<Alert
				onClose={handleClose}
				severity={snackbar.severity}
				sx={{ minWidth: '250px' }}
			>
				<AlertTitle>{toProperCase(snackbar.severity)}</AlertTitle>
				{snackbar.message}
			</Alert>
		</MaterialSnackbar>
	);
};

export default Snackbar;
