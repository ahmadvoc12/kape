import React, { lazy, LazyExoticComponent } from 'react';
import { Navigate } from 'react-router-dom';

import MainLayout from '@/layouts/main';
import AuthLayout from '@/layouts/auth';

const Dashboard = lazy(() => import('@/pages/dashboard'));
const Users = lazy(() => import('@/pages/users'));
const Login = lazy(() => import('@/pages/auth/login'));

interface IRoute {
	path: string;
	element: JSX.Element | LazyExoticComponent<() => JSX.Element>;
	children?: IRoute[];
}

const routes: IRoute[] = [
	{
		path: '/',
		element: <MainLayout />,
		children: [
			{
				path: 'dashboard',
				element: <Dashboard />
			},
			{
				path: 'users',
				element: <Users />
			},
			{
				path: '/',
				element: <Navigate to="dashboard" />
			}
		]
	},
	{
		path: '/auth',
		element: <AuthLayout />,
		children: [
			{
				path: '/login',
				element: <Login />
			}
		]
	}
];

export default routes;
